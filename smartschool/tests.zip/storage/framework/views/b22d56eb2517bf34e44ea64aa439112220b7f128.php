<?php /* C:\Users\Arun kundu\Desktop\smartschool1\Smart_school\smartschool\resources\views/admin/forms/result.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
<h4 id="e">RESULT</h4><br>
<div style="text-align: center;"><marquee style="width: 10%; background-color: black; color: white;" scrollamount="2" behavior = "alternate"><?php echo e(Session::get('msg')); ?></marquee></div>
<?php echo Form::open(['url' => '/save_result', 'method'=>'POST', 'enctype'=>'multipart/form-data']); ?>

  
  <div style="margin: 0 15%; " class="form-row">
     <div class="form-group col-md-4">
      <label for="inputEmail4">Class</label>
      <input type="text" class="form-control" id="inputPassword4" name="Class" placeholder="Class...." required>
    </div>
    <div class="form-group col-md-4">
      <label for="inputPassword4">Session</label>
      <input type="text" class="form-control" id="inputPassword4" name="Session" placeholder="Session......" required>
    </div>
   <div class="form-group col-md-4">
      <label for="inputEmail4">Exam name</label>
      <select id="inputState" class="form-control" name="Exam_name" required>
        <option disabled selected>Select...</option>
        <option>Half yearly</option>
        <option>Final</option>
        <option>Admission test</option>
      </select>
    </div>
    <div class="form-group col-md-4">
      <label for="inputEmail4">Result (CSV file)</label>
      <input type="file" class="form-control" id="Image" name="Result" placeholder="Result (must be CSV file)" required>
    </div>
    <div align="center" class="form-group col-md-12">
     <button type="submit" class="btn btn-primary">UPLOAD</button>
    </div>
</div>
  <?php echo Form::close(); ?>

  <div style="background-color: #7386D5; color: white; text-align: center;"><h4>Saved Result</h4> </div>
   <table style="text-align: center;" class="table">
    <thead>
      <tr>
        <th>Serial no</th>
        <th>Exam name</th>
        <th>Session</th>
        <th>Class</th>
        <th>View Result</th>
        <th>Download Result</th>
      </tr>
    </thead>
    <tbody>
      
      <?php
        $i =0; 
      ?>

      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(++$i); ?></td>
          <td><?php echo e($p->Exam_name); ?></td>
          <td><?php echo e($p->Session); ?></td>
          <td><?php echo e($p->Class); ?></td>
          <td><a href="<?php echo e(url('/view_result/'.$p->id)); ?>"><button class="btn btn-primary">VIEW</button></a>
          </td>
          <td><a href="<?php echo e(url('/download_result/'.$p->id)); ?>"><button class="btn btn-primary">DOWNLOAD</button></a>
          </td>
          <td><a href="<?php echo e(url('/delete_result/'.$p->id)); ?>"><button class="btn btn-primary">DOWNLOAD</button></a>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>