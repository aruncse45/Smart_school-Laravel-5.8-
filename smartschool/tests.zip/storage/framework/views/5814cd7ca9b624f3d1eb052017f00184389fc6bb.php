<?php /* C:\Users\Arun kundu\Desktop\smartschool1\Smart_school\smartschool\resources\views/admin/students/confirm_disable_students_profile.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
<h4 id="e">CONFIRM DISABLE STUDENT'S FORM</h4><br>
<div style="text-align: center;"><marquee style="width: 10%; background-color: black; color: white;" scrollamount="2" behavior = "alternate"><?php echo e(Session::get('msg')); ?></marquee></div>
<?php echo Form::open(['url' => '/confirm_disable_students_form', 'method'=>'POST', 'enctype'=>'multipart/form-data']); ?>

  
  <div style="margin-left: 30%; " class="form-row">
     <div class="form-group col-md-6">
      <label for="inputEmail4">Student ID</label>
      <input type="text" class="form-control" id="inputPassword4" name="Student_id" placeholder="Set student id.." required>
    </div><br>
    <div class="form-group col-md-8">
      <label for="inputPassword4"></label>
      Confirm : &nbsp;&nbsp;&nbsp;&nbsp;
      <input type="checkbox"  name="Confirm" required>
    </div>
    <input type="hidden" name="id" value="<?php echo e($id->id); ?>">
    
    <div align="center" class="form-group col-md-6">
     <button type="submit" class="btn btn-primary">SUBMIT</button>
    </div>
</div>
  <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>