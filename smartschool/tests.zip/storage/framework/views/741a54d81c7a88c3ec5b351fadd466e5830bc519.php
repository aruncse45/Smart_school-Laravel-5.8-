<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/user/home/teacher/teacher_info_show.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Teacher</title>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('admin/css/teacher.css')); ?>">
</head>
<body style="background-color: #313B3D; color: white">
<br>
  <div style="text-align: center; ">
    <h3 style="text-align: center; text-transform: uppercase;"><?php echo e($t->Name); ?></h3><br>
    <img  src="<?php echo e(URL::asset('admin/upload_image/'.$t->Image)); ?>"><br>
  </div>  
  

<!------ Include the above in your HEAD tag ---------->

<br/><br/>
<div class="tabs">
  <div class="tab-button-outer">
    <ul id="tab-button">
      <li><a href="" id="#tab01">PERSONAL &nbsp;&nbsp;&nbsp;&nbsp; INFORMATION</a></li>
      <li><a href="" id="#tab02">PROFESSIONAL INFORMATION</a></li>
      <li><a href="" id="#tab03">EDUCATIONAL INFORMATION</a></li>
      
       <li><a href="" id="#tab04">TRAINING/OTHER INFORMATION</a></li>
    </ul>
  </div>
  <div class="tab-select-outer">
    <select id="tab-select">
      <option value="#tab01">PERSONAL INFORMATION</option>
      <option value="#tab02">PROFESSIONAL INFORMATION</option>
      <option value="#tab03">EDUCATIONAL INFORMATION</option>
      
       <option value="#tab04">TRAINING/OTHER INFORMATION</option>
    </select>
  </div>

  <div id="tab01" class="tab-contents">
    <h5>Nick name : <?php echo e($t->Nick_name); ?></h5>
    <h5>Father's name : <?php echo e($t->Father_name); ?></h5>
    <h5>Mother's name : <?php echo e($t->Mother_name); ?></h5>
    <h5>Birth Date : <?php echo e($t->Birth_date); ?></h5>
    <h5>Gender : <?php echo e($t->Gender); ?></h5>
    <h5>Blood group : <?php echo e($t->Blood_group); ?></h5>
    <h5>Mobile no : <?php echo e($t->Mobile_no); ?></h5>
    <h5>Address : <?php echo e($t->Address); ?>,<?php echo e($t->District); ?>,<?php echo e($t->Division); ?></h5>
    <h5>Nationality : <?php echo e($t->Nationality); ?></h5>
  </div>
  <div id="tab02" class="tab-contents">
    <h5>Employee ID : <?php echo e($t->Employee_id); ?></h5>
    <h5>Join Date : <?php echo e($t->Join_date); ?></h5>
    <h5>Designation : <?php echo e($t->Designation); ?></h5>
    <h5>Other Designation : <?php echo e($t->Other_role); ?></h5>
    <h5>Qualification : <?php echo e($t->Qualification); ?></h5>
    <h5>Specialized Subject : <?php echo e($t->Specialized_subject); ?></h5>
    <h5>Gmail Account : <?php echo e($t->Gmail_account); ?></h5>
    <h5>Google Drive : <?php echo e($t->Google_drive); ?></h5>
    <h5>Social Media<?php echo e($t->Social_media); ?></h5>
    
    
  </div>
  <div id="tab03" class="tab-contents">
    <table style="text-align: center;" class="table table-striped">
      <tr>
        <th>INSTITUTE NAME</th>
        <th>NAME OF DEGREE</th>
        <th>COUNTRY</th>
      </tr>
      <tr>
        <td><?php echo e($t->Ssc); ?></td>
        <td>SSC</td>
        <td>Bangladesh</td>
      </tr>
      <tr>
        <td><?php echo e($t->Hsc); ?></td>
        <td>HSC <?php echo e($t->faculty); ?></td>
        <td>Bangladesh</td>
      </tr>
      <tr>
        <td><?php echo e($t->C_U); ?></td>
        <td><?php echo e($t->Degree); ?></td>
        <td>Bangladesh</td>
      </tr>
    </table>
  </div>
  <div id="tab04" class="tab-contents">
    <h5>Training : <?php echo e($t->Training); ?></h5>
    <h5> Other : <?php echo e($t->Other); ?></h5>
    
  </div>
</div>
<script type="text/javascript" src="<?php echo e(URL::asset('admin/js/teacher.js')); ?>"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>

</body>
</html>





