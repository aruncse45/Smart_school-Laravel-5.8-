<?php /* C:\Users\Arun kundu\Desktop\smartschool1\Smart_school\smartschool\resources\views/admin/profile.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
<h4 id="e">ADMIN PROFILE</h4>
<br><br>
<div style="margin: 0 15%">
    Name : <?php echo e($profile->name); ?><br>
    Email: <?php echo e($profile->email); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>