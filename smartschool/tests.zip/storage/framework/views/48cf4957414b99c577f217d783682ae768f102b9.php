<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/user/home/ebooks.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
<br>
	<h4 style="text-align: center;">EBOOKS</h4><br>
	<div style="height: 100px; margin: 0 10%; color: blue">
		<?php $__currentLoopData = $ebooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ebook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		Name : <?php echo e($ebook->Name); ?><br>
		<a href="<?php echo e(URL::asset('admin/upload_pdf/'.$ebook->Ebook)); ?>">Click here for view</a> <br><br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>