<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/admin/csv/download_due.blade.php */ ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Download Due</title>
    <style type="text/css">
      table, th,td{border: 1px solid black;}
    </style>
  </head>
  <body>
  <h3 style="text-align: center; text-transform: uppercase;"><?php echo e($school->School_name); ?></h3>
  <h4 style="text-align: center;"> STUDENT'S DUE </h4>
  <h4 style="text-align: center;">CLASS : <?php echo e($class); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SESSION :<?php echo e($session); ?></h4>
  <hr>
  <table style="text-align: center; width: 100%" align="center" >
    <thead>
      <tr>
        <th>id</th>
        <th>Roll</th>
        <th>Name</th>
        <th>Monthly Due</th>
        <th>Exam Due</th>
        <th>Other</th>
      </tr>
    </thead>
    <tbody>
      
    <?php
      $i =0; 
    ?>

      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(++$i); ?></td>
          <td><?php echo e($p->Roll); ?></td>
          <td><?php echo e($p->Name); ?></td>
          <td><?php echo e($p->Monthly_due); ?></td>
          <td><?php echo e($p->Exam_due); ?></td>
          <td><?php echo e($p->other); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>

  </body>
  </html>
  
