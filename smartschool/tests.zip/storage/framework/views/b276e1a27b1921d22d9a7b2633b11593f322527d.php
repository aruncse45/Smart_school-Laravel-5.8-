<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/admin/forms/routine.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
<h4 id="e">ROUTINE</h4><br><br>
<div style="text-align: center;"><marquee style="width: 10%; background-color: black; color: white;" scrollamount="2" behavior = "alternate"><?php echo e(Session::get('msg')); ?></marquee></div>
<?php echo Form::open(['url' => '/save_routine', 'method'=>'POST', 'enctype'=>'multipart/form-data']); ?>

  

    <div class="form-group">
      <label for="inputEmail4">Class</label>
      <input type="text" class="form-control" id="inputPassword4" name="Class" placeholder="Class...." required>
    </div>
    <div class="form-group">
      <label for="inputPassword4">Session</label>
      <input type="text" class="form-control" id="inputPassword4" name="Session" placeholder="Session......" required>
    </div>
    <div class="form-group">
      <label for="inputPassword4">Section</label>
      <input type="text" class="form-control" id="inputPassword4" name="Section" placeholder="Section......">
    </div>
    <div class="form-group">
      <label for="inputEmail4">Routine (pdf file)</label>
      <input type="file" class="form-control" id="Image" name="Routine" placeholder="" required>
    </div>

  
  <button type="submit" class="btn btn-lg btn-success btn-block">Submit</button>

<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>