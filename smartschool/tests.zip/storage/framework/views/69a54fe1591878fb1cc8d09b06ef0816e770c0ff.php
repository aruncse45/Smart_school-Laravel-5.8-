<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/admin/csv/export_attendence_fetch.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>

  <h4 id="e">EXPORT ATTENDENCE</h4>
  <hr>

  <a href="<?php echo e(url('/download_attendence')); ?>"> <button type="submit" class="btn btn-primary">DOWNLOAD ATTENDENCE</button></a>
  <hr>
  <table class="table">
    <thead>
      <tr>
        <th>id</th>
        <th>Name</th>
        <th>Roll</th>
        <th>P_A</th>
       
      </tr>
    </thead>
    <tbody>
      
    <?php
      $i =0; 
    ?>
      
      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(++$i); ?></td>
          <td><?php echo e($p->Name); ?></td>
          <td><?php echo e($p->Roll); ?></td>
          
          <td><?php echo e($attendence[$p->Roll][0]->c); ?></td>
         
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </tbody>
  </table>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>