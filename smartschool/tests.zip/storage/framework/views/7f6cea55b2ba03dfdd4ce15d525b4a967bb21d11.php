<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/user/home/academic/show_brs.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
<h4 id="e" style="text-align: center;">ROUTINE BOOLIST SYLLABUS</h4><br><br>
<div style="text-align: center;"><marquee style="width: 10%; background-color: black; color: white;" scrollamount="2" behavior = "alternate"><?php echo e(Session::get('msg')); ?></marquee></div>

<div align="center">
<object data="<?php echo e(URL::asset('admin/upload_pdf/'.$result->Pdf)); ?>" type="application/pdf" width="70%" height="500px">
<a href="<?php echo e(URL::asset('admin/upload_pdf/'.$result->Pdf)); ?>">test.pdf</a>
</object>
</div><br>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>