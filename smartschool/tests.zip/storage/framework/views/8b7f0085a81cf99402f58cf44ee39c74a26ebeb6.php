<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/admin/csv/export_attendence.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
<h4 id="e">RESULT</h4><br><br>
<?php echo e(Session::get('msg')); ?>

<?php echo Form::open(['url' => '/export_attendence_fatch', 'method'=>'POST', 'enctype'=>'multipart/form-data']); ?>

  

    <div class="form-group">
      <label for="inputEmail4">Class</label>
      <input type="text" class="form-control" id="inputPassword4" name="Class" placeholder="Class...." required>
    </div>
    <div class="form-group">
      <label for="inputPassword4">Session</label>
      <input type="text" class="form-control" id="inputPassword4" name="Session" placeholder="Session......" required>
    </div>
   <div class="form-group">
      <label for="inputPassword4">Month</label>
      <input type="month" class="form-control" id="inputPassword4" name="Month" placeholder="Session......" >
    </div>

  
  <button type="submit" class="btn btn-lg btn-success btn-block">Submit</button>

<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>