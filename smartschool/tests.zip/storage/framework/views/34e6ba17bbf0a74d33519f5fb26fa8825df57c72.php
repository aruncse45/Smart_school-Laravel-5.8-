<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/user/home/attendence/attendence_sheet.blade.php */ ?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <title></title>
</head>
<body>
  <br>

<h4 style="text-align: center;" >ATTENDENCE SHEET</h4>
<h6 style="text-align: center;">Class: <?php echo e($data['class']); ?>, Section: <?php echo e($data['section']); ?>, Session: <?php echo e($data['session']); ?>, Date: <?php echo e($data['date']); ?></h6>
  <hr>
  <?php echo Form::open(['url' => '/save_attendence', 'method'=>'POST', 'enctype'=>'multipart/form-data']); ?>

  <table  class="table table-striped">
    <thead>
      <tr>
        <th>Roll</th>
        <th>Name</th>
        <th>P/A</th>
      </tr>
    </thead>
    <tbody>

      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
    <td><?php echo e($p->Roll); ?></td>
    <td><?php echo e($p->Name); ?></td>

    <td><input type="checkbox" name="<?php echo e($p->Roll); ?>" value="yes"></td>
    <input type="hidden" name="Roll" value="<?php echo e($p->Roll); ?>">
    <input type="hidden" name="Name" value="<?php echo e($p->Name); ?>">
    </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </tbody>

  </table>
  <td><input type="hidden" name="Class" value="<?php echo e($data['class']); ?>"></td>
    <td><input type="hidden" name="Session" value="<?php echo e($data['session']); ?>"></td>
    <td><input type="hidden" name="Date" value="<?php echo e($data['date']); ?>"></td>
    
    <button style=" margin: auto;" type="submit" class="btn btn-primary">Submit</button>
  <?php echo Form::close(); ?>

</body>
</html>







  




