<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/admin/csv/download_attendence.blade.php */ ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Download Attendence</title>
    <style type="text/css">
      table, th,td{border: 1px solid black;}
    </style>
  </head>
  <body>
  <h3 style="text-align: center; text-transform: uppercase;"><?php echo e($school->School_name); ?></h3>
  <h4 style="text-align: center;"> ATTENDENCE </h4>
  <h4 style="text-align: center;">CLASS : <?php echo e($class); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SESSION :<?php echo e($session); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Month : <?php echo e($month); ?></h4>
  <hr>
   <table style="text-align: center; width: 100%" align="center" >
    <thead>
      <tr>
        <th>Serial no</th>
        <th>Roll</th>
        <th>Name</th>
        <th>P_A</th>
       
      </tr>
    </thead>
    <tbody>
      
    <?php
      $i =0; 
    ?>

      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(++$i); ?></td>
          <td><?php echo e($p->Roll); ?></td>
          <td><?php echo e($p->Name); ?></td>
          <td><?php echo e($attendence[$p->Roll][0]->c); ?></td>
         
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>

  </body>
  </html>
  





  