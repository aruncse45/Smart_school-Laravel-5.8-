<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/admin/csv/export_due_csv.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>

  <h4 id="e">STUDENTS DUE csv</h4><br><br>
  <h5 style="text-align: center; color: black">CLASS : <?php echo e($class1); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SESSION :<?php echo e($session1); ?></h5>
  <hr>

  <a href="<?php echo e(url('/download_students_due')); ?>"> <button type="submit" class="btn btn-primary">DOWNLOAD DUE</button></a>
  <hr>
  <table class="table">
    <thead>
      <tr>
        <th>id</th>
        <th>Roll</th>
        <th>Name</th>
        <th>Monthly Due</th>
        <th>Exam Due</th>
        <th>Other</th>
      </tr>
    </thead>
    <tbody>
      
    <?php
      $i =0; 
    ?>

      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(++$i); ?></td>
          <td><?php echo e($p->Roll); ?></td>
          <td><?php echo e($p->Name); ?></td>
          <td><?php echo e($p->Monthly_due); ?></td>
          <td><?php echo e($p->Exam_due); ?></td>
          <td><?php echo e($p->other); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>