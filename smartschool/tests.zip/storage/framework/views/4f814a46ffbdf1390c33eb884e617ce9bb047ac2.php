<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/user/home/teacher/all_teacher.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
<br>
	<h4 style="text-align: center;">ALL TEACHER</h4><br>
	<?php $__currentLoopData = $all_teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="a" style="text-align: center; float: left;">
		<a class="photo" href="<?php echo e(url('/teacher/'.$p->Employee_id)); ?>">
			<img  src="<?php echo e(URL::asset('admin/upload_image/'.$p->Image)); ?>">
		</a>
		<h4><?php echo e($p->Name); ?></h4>
		<h4><?php echo e($p->Qualification); ?></h4>
	</div>
	
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>