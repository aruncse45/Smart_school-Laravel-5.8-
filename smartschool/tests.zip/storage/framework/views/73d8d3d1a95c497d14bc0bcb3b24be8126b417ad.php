<?php /* C:\Users\Arun kundu\Desktop\smartschool1\Smart_school\smartschool\resources\views/admin/students/students_history.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
<h4 id="e">STUDENT HISTORY (permanent)</h4><br>
<div style="text-align: center;"><marquee style="width: 10%; background-color: black; color: white;" scrollamount="2" behavior = "alternate"><?php echo e(Session::get('msg')); ?></marquee></div>
<?php echo Form::open(['url' => '/student_history_form', 'method'=>'POST', 'enctype'=>'multipart/form-data']); ?>

  
  <div style="margin: 0 15%; " class="form-row">
     <div class="form-group col-md-6">
      <label for="inputEmail4">Class</label>
      <input type="text" class="form-control" id="inputPassword4" name="Class" placeholder="Class...." required>
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Session</label>
      <input type="text" class="form-control" id="inputPassword4" name="Session" placeholder="Session......" required>
    </div>
    <br>
    <div align="center" class="form-group col-md-12">
     <button type="submit" class="btn btn-primary">SUBMIT</button>
    </div>
</div>
  <?php echo Form::close(); ?>

  <?php if($data['total_result']>0): ?>
  <div style="background-color: #7386D5; color: white; text-align: center;"><h4>RESULT</h4> </div>
  <div style="text-align: center;">
    
    Class : <?php echo e($data['Class']); ?> ||
    Session : <?php echo e($data['Session']); ?> 
    
    <br>
    Total student's : <?php echo e($data['total_result']); ?>

 
   <table style="text-align: center;" class="table">
    <thead>
      <tr>
        <th>Admission id</th>
        <th>Student's name</th>
        <th>Admission Date</th>
        <th>Class</th>
        <th>Session</th>
        <th>Mobile No</th>
        <th>Father's name</th>
        <th>Father's mobile no</th>
      </tr>
    </thead>
    <tbody>
      
      <?php
        $i =0; 
      ?>
	
	<?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($p->Student_id); ?></td>
          <td><?php echo e($p->Name); ?></td>
          <td><?php echo e($p->created_at); ?></td>
          <td><?php echo e($p->Class); ?></td>
          <td><?php echo e($p->Session); ?></td>
          <td><?php echo e($p->Mobile_no); ?></td>
          <td><?php echo e($p->Fathers_name); ?></td>
          <td><?php echo e($p->Fathers_mobile_no); ?></td>
          
          
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	     
	<?php endif; ?>
    </tbody>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>