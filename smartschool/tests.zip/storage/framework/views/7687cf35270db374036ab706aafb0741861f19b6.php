<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/admin/forms/ex_students.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
  
  <h4 id="e">ABOUT SCHOOL</h4><br><br>
  <div style="text-align: center;"><marquee style="width: 10%; background-color: black; color: white;" scrollamount="2" behavior = "alternate"><?php echo e(Session::get('msg')); ?></marquee>
  </div>
  <table class="table">
    <thead>
      <tr>
        <th>id</th>
        <th>Name</th>
        <th>Present Status</th>
        <th>Speech</th>
        <th>Image</th>
        <th>Operation</th>
      </tr>
    </thead>
    <tbody>
      
      <?php
        $i =0; 
      ?>

      <?php $__currentLoopData = $ex_students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(++$i); ?></td>
          <td><?php echo e($p->Name); ?></td>
          <td><?php echo e($p->Present_status); ?></td>
          <td><?php echo e($p->Speech); ?></td>
          <td><img style="height: 50px; width: 50px" src="<?php echo e(URL::asset('admin/upload_image/'.$p->Image)); ?>"></td>
          <td><a href="<?php echo e(url('/update_ex_student_form/'.$p->id)); ?>">UPDATE</a></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>