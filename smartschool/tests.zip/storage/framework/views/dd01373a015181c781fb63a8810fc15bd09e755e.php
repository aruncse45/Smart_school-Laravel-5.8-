<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/user/home/result/board_result.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
<br>

<h4 style="text-align: center;">BOARD RESULT</h4><br>
	
	<table class="table table-striped">
		<thead style="text-align: center;">
	      <tr>
	        <th>Serial no</th>
	        <th>Year</th>
	        <th>Exam Type</th>
	        <th>Total student</th>
	        <th>Pass</th>
	        <th>Fail</th>
	        <th>A Plus</th>
	        <th>Percentage %</th>
	      </tr>
      </thead>
      <tbody >
      <?php
        $i =0; 
      ?>

      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(++$i); ?></td>
          <td><?php echo e($p->Year); ?></td>
          <td><?php echo e($p->Exam_type); ?></td>
          <td><?php echo e($p->Total_student); ?></td>
          <td><?php echo e($p->Pass); ?></td>
          <td><?php echo e($p->Fail); ?></td>
          <td><?php echo e($p->A_plus); ?></td>
          <td><?php echo e($p->Percentage); ?></td>
		</tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
    </table>

<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>