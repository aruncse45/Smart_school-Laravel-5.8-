<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/admin/include/sidebar.blade.php */ ?>

<!--id f silo.....-->


<ul id="" style="margin-top: 0;" class="list-unstyled components">
    
    <li>
        <a  href="#pageSubmenu44" data-toggle="collapse" aria-expanded="false"  style="text-align: center;" ><button style="background-color: red; color: white" class="btn btn-lg btn-success btn-block">MENU</button> 
        </a>
        <ul class="collapse list-unstyled" id="pageSubmenu44">
            <li>
                <a id="a1" class="facility" href="<?php echo e(url('/new_notice_news_events')); ?>"><i class="fa fa-list-alt" aria-hidden="true"></i> NOTICE/EVENTS/NEWS</a>
            </li>
            <li>
                <a id="a2" class="facility" href="<?php echo e(url('/about_school')); ?>"><i class="fa fa-address-card" aria-hidden="true"></i> ABOUT SCHOOL</a>
            </li>
            <li>
                <a id="a3" class="facility" href="<?php echo e(url('/speech')); ?>"><i class="fa fa-comments" aria-hidden="true"></i> SPEECH</a>
            </li>
            <li>
                <a id="a3" class="facility" href="<?php echo e(url('/footer')); ?>"><i class="fa fa-comments" aria-hidden="true"></i> FOOTER</a>
            </li>
            <li>
                <a id="a3" class="facility" href="<?php echo e(url('/contact_info')); ?>"><i class="fa fa-comments" aria-hidden="true"></i> CCNTACT INFO</a>
            </li>
            <li>
                <a id="a3" class="facility" href="<?php echo e(url('/ex_students')); ?>"><i class="fa fa-comments" aria-hidden="true"></i> EX STUDENT</a>
            </li>
            <li>
                <a href="#pageSubmenu1" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-user" aria-hidden="true"></i> TEACHER
                </a>
                <ul class="collapse list-unstyled" id="pageSubmenu1">
                    <li>
                        <a id="a4" class="facility" href="<?php echo e(url('/teachers_staffs_profile')); ?>">CREATE PROFILE</a>
                    </li>
                    <li>
                        <a id="a5" class="facility" href="<?php echo e(url('/change_teachers_staffs_profile')); ?>">UPDATE PROFILE</a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#pageSubmenu9" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-user" aria-hidden="true"></i> COMMITTE
                </a>
                <ul class="collapse list-unstyled" id="pageSubmenu9">
                    <li>
                        <a id="a4" class="facility" href="<?php echo e(url('/committe_profile')); ?>">CREATE PROFILE</a>
                    </li>
                    <li>
                        <a id="a5" class="facility" href="<?php echo e(url('/show_committe_profile')); ?>">UPDATE PROFILE</a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#pageSubmenu2" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-user" aria-hidden="true"></i> STUDENT'S PROFILE
                </a>
                <ul class="collapse list-unstyled" id="pageSubmenu2">
                    <li>
                        <a id="a4" class="facility" href="<?php echo e(url('/student_profile')); ?>">CREATE PROFILE</a>
                    </li>
                    <li>
                        <a id="a5" class="facility" href="<?php echo e(url('/visit_student_profile')); ?>">VISIT PROFILE</a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#pageSubmenu8" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-user" aria-hidden="true"></i> PRESENT STDENTS
                </a>
                <ul class="collapse list-unstyled" id="pageSubmenu8">
                    <li>
                        <a id="a4" class="facility" href="<?php echo e(url('/present_students')); ?>">UPLOAD</a>
                    </li>
                    <li>
                        <a id="a5" class="facility" href="<?php echo e(url('/export_attendence')); ?>">EXPORT</a>
                    </li>
                </ul>
            </li>
            <li>
                 <a href="#pageSubmenu7" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-user" aria-hidden="true"></i> STUDENT DUE
                </a>
                <ul class="collapse list-unstyled" id="pageSubmenu7">
                    <li>
                        <a id="a4" class="facility" href="<?php echo e(url('/students_due')); ?>">UPLOAD</a>
                    </li>
                    <li>
                        <a id="a5" class="facility" href="<?php echo e(url('/export_due')); ?>">EXPORT</a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#pageSubmenu3" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-table" aria-hidden="true"></i> RESULT
                </a>
                <ul class="collapse list-unstyled" id="pageSubmenu3">
                    <li>
                        <a id="a4" class="facility" href="<?php echo e(url('/result')); ?>">SCHOOL RESULT UPLOAD</a>
                    </li>
                    <li>
                        <a id="a4" class="facility" href="<?php echo e(url('/board_result')); ?>">BOARD RESULT UPLOAD</a>
                    </li>
                    <li>
                        <a id="a5" class="facility" href="<?php echo e(url('/exportresult')); ?>">EXPORT</a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#pageSubmenu4"data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-table" aria-hidden="true"></i> SYLLABUS</a>
                <ul class="collapse list-unstyled" id="pageSubmenu4">
                    <li>
                        <a id="a4" class="facility" href="<?php echo e(url('/syllabus')); ?>">UPLOAD</a>
                    </li>
                    <li>
                        <a id="a5" class="facility" href="<?php echo e(url('/show_all_syllabus')); ?>"> SEE ALL and UPDATE</a>
                    </li>
                </ul>
            </li>
             <li>
                <a href="#pageSubmenu5" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-user" aria-hidden="true"></i> ROUTINE
                </a>
                <ul class="collapse list-unstyled" id="pageSubmenu5">
                    <li>
                        <a id="a4" class="facility" href="<?php echo e(url('/routine')); ?>">UPLOAD</a>
                    </li>
                    <li>
                        <a id="a5" class="facility" href="<?php echo e(url('/show_all_routine')); ?>">SEE ALL AND UPDATE</a>
                    </li>
                </ul>
            </li>
            <li>
                <a id="a10" class="facility"  href="<?php echo e(url('/booklist')); ?>"><i class="fa fa-book" aria-hidden="true"></i> BOOK LIST</a>
            </li>
            <li>
                <a id="a10" class="facility"  href="<?php echo e(url('/ebook')); ?>"><i class="fa fa-book" aria-hidden="true"></i> EBOOK</a>
            </li>
            <li>
                <a href="#pageSubmenu6" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-table" aria-hidden="true"></i> IMAGE GALLERY
                </a>
                <ul class="collapse list-unstyled" id="pageSubmenu6">
                    <li>
                        <a id="a4" class="facility" href="<?php echo e(url('/image_gallery')); ?>">UPLOAD</a>
                    </li>
                    <li>
                        <a id="a5" class="facility" href="<?php echo e(url('/show_images')); ?>">SHOW ALL</a>
                    </li>
                </ul>
            </li>
        </ul>
    </li>

    
</ul>