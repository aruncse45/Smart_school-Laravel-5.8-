<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/user/home/image_gallery.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
<br>
	<h4 style="text-align: center;">IMAGE GALLERY</h4><br>
	<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<a class="photo" href="<?php echo e(URL::asset('admin/upload_image/'.$image->image)); ?>">
		<img  src="<?php echo e(URL::asset('admin/upload_image/'.$image->image)); ?>">

	</a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>