<?php /* C:\Users\Arun kundu\Desktop\smartschool1\Smart_school\smartschool\resources\views/admin/forms/visit_student_profile.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
<h4 id="e">STUDENT INFO</h4><br><br>
<div style="text-align: center;"><marquee style="width: 30%; background-color: black; color: white;" scrollamount="2" behavior = "alternate"><?php echo e(Session::get('msg')); ?></marquee></div>
<?php echo Form::open(['url' => '/view_student_profile', 'method'=>'POST', 'enctype'=>'multipart/form-data']); ?>

  <div style="margin: 0 15%; z-index: 1000000; " class="form-row">
    <div class="form-group col-md-4">
      <label for="inputEmail4">Student ID</label>
      <input type="text" class="form-control" id="inputPassword4" name="Student_id" placeholder="Class...." >
    </div>
    <div class="form-group col-md-4">
      <label for="inputEmail4">Class</label>
      <input type="text" class="form-control" id="inputPassword4" name="Class" placeholder="Class...." >
    </div>
    <div class="form-group col-md-4">
      <label for="inputPassword4">Session</label>
      <input type="text" class="form-control" id="inputPassword4" name="Session" placeholder="Session......">
    </div>
    <div class="form-group col-md-4">
      <label for="inputPassword4">Roll</label>
      <input type="text" class="form-control" id="inputPassword4" name="Roll" placeholder="Section......" >
    </div>
    <div style="text-align: center;" class="form-group col-md-12">
     <button type="submit" class="btn btn-primary">Submit</button><br>
    </div>
  
</div>
<?php echo Form::close(); ?>


 <div style="background-color: #7386D5; color: white; text-align: center;"><h4>Student's Profile</h4> </div>
 
   <div align="center" style="font-size: 20px">
     
      <?php if (count($result)>0) { ?>   
      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
          <img style="height: 100px; width: 100px" src="<?php echo e(URL::asset('admin/upload_image/'.$p->Image)); ?>"><br><br>
          <table>
            <tr style="text-align: left;"><td>Student_id :</td><td> <?php echo e($p->Student_id); ?></td></tr>
            <tr style="text-align: left;"><td>Name :</td><td><?php echo e($p->Name); ?></td></tr>
            <tr style="text-align: left;"><td>Nick name :</td><td><?php echo e($p->Nick_name); ?></td></tr>
            <tr style="text-align: left;"><td>Class :</td><td><?php echo e($p->Class); ?></td></tr>
             <tr style="text-align: left;"><td>Section :</td><td><?php echo e($p->Section); ?></td></tr>
            <tr style="text-align: left;"><td>Session :</td><td><?php echo e($p->Session); ?></td></tr>

            <tr style="text-align: left;"><td>Roll :</td><td><?php echo e($p->Roll); ?></td></tr>
            <tr style="text-align: left;"><td>Psc_grade :</td><td><?php echo e($p->Psc_grade); ?></td></tr>
            <tr style="text-align: left;"><td>Jsc_grade :</td><td><?php echo e($p->Jsc_grade); ?></td></tr>
            <tr style="text-align: left;"><td>Department :</td><td><?php echo e($p->Department); ?></td></tr>
            <tr style="text-align: left;"><td>Birth_date :</td><td><?php echo e($p->Birth_date); ?></td></tr>
            <tr style="text-align: left;"><td>Gender :</td><td><?php echo e($p->Gender); ?></td></tr>
            <tr style="text-align: left;"><td>Blood_group :</td><td> <?php echo e($p->Blood_group); ?></td></tr>
            <tr style="text-align: left;"><td>Religion :</td><td> <?php echo e($p->Religion); ?></td></tr>
            <tr style="text-align: left;"><td>Mobile No :</td><td><?php echo e($p->Mobile_no); ?></td></tr>
            <tr style="text-align: left;"><td>Address :</td><td><?php echo e($p->Address); ?></td></tr>
            <tr style="text-align: left;"><td>Extra_activities :</td><td><?php echo e($p->Extra_activities); ?></td></tr>
           <tr style="text-align: left;"><td>Admission_date :</td><td><?php echo e($p->created_at); ?></td></tr><br>
            <tr style="text-align: left;"><td>Fathers_name :</td><td><?php echo e($p->Fathers_name); ?></td></tr>
            <tr style="text-align: left;"><td>Fathers_occupation :</td><td> <?php echo e($p->Fathers_occupation); ?></td></tr>
            <tr style="text-align: left;"><td>Fathers_mobile_no :</td><td> <?php echo e($p->Fathers_mobile_no); ?></td></tr>
            <tr style="text-align: left;"><td>Mothers_name :</td><td><?php echo e($p->Mothers_name); ?></td></tr>
            <tr style="text-align: left;"><td>Mothers_mobile_no :</td><td><?php echo e($p->Mothers_mobile_no); ?></td></tr>
            <tr style="text-align: left;"><td>Mothers_occupation :</td><td><?php echo e($p->Mothers_occupation); ?></td></tr>
             
             
          </table>
        
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
    </div><br><br>
        <?php }?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>