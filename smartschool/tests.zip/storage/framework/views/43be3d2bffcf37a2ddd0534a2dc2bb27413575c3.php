<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/user/home/student/sidebar.blade.php */ ?>
<div style="text-align: center;" class="sidebar-header">
    <h3>PROFILE</h3>
</div>

<div style="text-align: center; overflow: auto;">
     <?php $__currentLoopData = $student_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img style="height: 50%; width: 50%;"  src="<?php echo e(URL::asset('admin/upload_image/'.$p->Image)); ?>">
            <br><br>
            
            Student ID : <?php echo e($p->Student_id); ?><br><br>
            Name : <?php echo e($p->Name); ?><br><br>
            Father's name : <?php echo e($p->Father_name); ?><br><br>
            Mother's name : <?php echo e($p->Mother_name); ?><br><br>
            Class : <?php echo e($p->Class); ?><br><br>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
    