<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/user/home/result/download_result.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>admission form</title>
  <style type="text/css">
      table,th,td{border: 1px solid black}
    </style>
</head>
<body>
  
  <div align="center" style="font-size: 20px">
      <?php $__currentLoopData = $student_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
          <h4 style="text-transform: uppercase;"><?php echo e($about_us->School_name); ?></h4>
          <h4 style="text-transform: uppercase;">RESULT OF <?php echo e($p->Exam_name); ?> EXAM</h4>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>  
<hr>
  <div style="font-size: 20px">
      <?php $__currentLoopData = $student_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        Name : <?php echo e($p->Name); ?><br>
        Roll : <?php echo e($p->Roll); ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
    <div align="center" style="font-size: 20px">
       <h4 style="text-transform: uppercase;">MARK SHEET</h4>
      <?php $__currentLoopData = $student_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
          <table style="text-align: center; width: 50%" align="center" >
            <tr><td>SUBJECT</td><td>MARK</td></tr>
            <tr style="text-align: left;"><td>Bangla :</td><td> <?php echo e($p->Bangla_1st); ?></td></tr>
            <tr style="text-align: left;"><td>Bangla :</td><td> <?php echo e($p->Bangla_2nd); ?></td></tr>
            <tr style="text-align: left;"><td>English :</td><td><?php echo e($p->English_1st); ?></td></tr>
            <tr style="text-align: left;"><td>English :</td><td><?php echo e($p->English_2nd); ?></td></tr>
            <tr style="text-align: left;"><td>Math :</td><td><?php echo e($p->General_math); ?></td></tr>
            <tr style="text-align: left;"><td>Physics :</td><td><?php echo e($p->Physics); ?></td></tr>
            <tr style="text-align: left;"><td>Chemistry :</td><td><?php echo e($p->Chemistry); ?></td></tr>
            <tr style="text-align: left;"><td>Biology :</td><td><?php echo e($p->Biology); ?></td></tr>
            <tr style="text-align: left;"><td>Highermath :</td><td><?php echo e($p->Highermath); ?></td></tr>
            <tr style="text-align: left;"><td>Religion :</td><td><?php echo e($p->Religion); ?></td></tr>
            <tr style="text-align: left;"><td>Socialscience :</td><td> <?php echo e($p->Socialscience); ?></td></tr>
             <tr style="text-align: left;"><td>Socialscience :</td><td> <?php echo e($p->Bangla_1st); ?>+<?php echo e($p->Bangla_2nd); ?></td></tr>
           
             
          </table>
        
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html>
  
