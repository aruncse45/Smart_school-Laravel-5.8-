<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/admin/forms/show_images.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
	<h4 id="e">Select  image for Homepage</h4><br><br>
	<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<?php echo Form::open(['url' => '/select_images', 'method'=>'POST', 'enctype'=>'multipart/form-data']); ?>


		<input type="checkbox" name="<?php echo e($image->id); ?>" value="select">
		<img style="height: 200px; width: 200px" src="<?php echo e(URL::asset('admin/upload_image/'.$image->image)); ?>"> <br><br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  	<button style=" margin: auto; width: 15%" type="submit" class="btn btn-primary">SET</button><br><br>
	  	<br>
	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>