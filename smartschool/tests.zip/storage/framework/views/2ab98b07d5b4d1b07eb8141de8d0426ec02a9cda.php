<?php /* C:\Users\Arun kundu\Desktop\smartschool1\Smart_school\smartschool\resources\views/admin/csv/export_result_csv.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>

  <h4 id="e">STUDENT'S RESULT</h4>
  <hr>
  <a href="<?php echo e(url('/downloadresult')); ?>"><button type="submit" class="btn btn-primary">DOWNLOAD RESULT</button></a>

  <hr>
  <table class="table">
    <thead>
      <tr>
        <th>id</th>
        <th>Class</th>
        <th>Session</th>
        <th>Name</th>
        <th>Roll</th>
        <th>Bangla</th>
      </tr>
    </thead>
    <tbody>
      
    <?php
      $i =0; 
    ?>

      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(++$i); ?></td>
          <td><?php echo e($p->Class); ?></td>
          <td><?php echo e($p->Session); ?></td>
          <td><?php echo e($p->Name); ?></td>
          <td><?php echo e($p->Roll); ?></td>
          <td><?php echo e($p->Bangla_1st); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>