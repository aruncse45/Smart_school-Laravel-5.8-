<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/admin/forms/speech.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
  <?php echo e(Session::get('msg')); ?>

  <h4 id="e">SPEECH</h4><br><br>
  <div style="text-align: center;"><marquee style="width: 10%; background-color: black; color: white;" scrollamount="2" behavior = "alternate"><?php echo e(Session::get('msg')); ?></marquee></div>
  <table class="table">
    <thead>
      <tr>
        <th>Serial no</th>
        <th>Speaker's name</th>
        <th>Designation</th>
        <th>Speaker's image</th>
        <th>Speech</th>
        <th>Operation</th>
      </tr>
    </thead>
    <tbody>
      
    <?php
      $i =0; 
    ?>

      <?php $__currentLoopData = $speech; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
    <td><?php echo e(++$i); ?></td>
    <td><?php echo e($p->Speaker_name); ?></td>
    <td><?php echo e($p->Designation); ?></td>
    <td><img style="height: 50px; width: 50px" src="<?php echo e(URL::asset('admin/upload_image/'.$p->Speaker_image)); ?>"></td>
        
        <td><?php echo e($p->speech); ?></td>
        
        <td><a href="<?php echo e(url('/update_speech_form/'.$p->id)); ?>">UPDATE</a></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>