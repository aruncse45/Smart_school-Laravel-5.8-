<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/user/home/teacher/facility.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
	
	<div id="div1" class="form" style="display: ">
		<!DOCTYPE html>
		<html lang="en">
			<head>
			  <title>Bootstrap Example</title>
			  <meta charset="utf-8">
			  <meta name="viewport" content="width=device-width, initial-scale=1">
			  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
			  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
			</head>
			<body>

			<div class="container">
			  <h2>SYLLABUS</h2>
			  <ul class="nav nav-tabs">
				<?php 
					$i = 0;
				?>
				<?php $__currentLoopData = $syllabus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php 	if($i==0){ ?>
						<li class="active"><a data-toggle="tab" href="#menu<?php echo e($p->Class); ?>">Class <?php echo e($p->Class); ?></a></li>
					<?php $i++;
					 } 
			 		else{ ?> 	
			 			<li><a data-toggle="tab" href="#menu<?php echo e($p->Class); ?>">Class <?php echo e($p->Class); ?></a></li>
			 		<?php $i++; } ?>	
		 		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  </ul>

			  <div class="tab-content">
				<?php 
					$i = 0;
				 ?>
				<?php $__currentLoopData = $syllabus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
				<?php 	if($i==0){ ?>
			  		<div id="menu<?php echo e($p->Class); ?>" class="tab-pane fade in active">
			    		
			    		<div align="center">
							<object data="<?php echo e(URL::asset('admin/upload_pdf/'.$p->Pdf)); ?>" type="application/pdf" width="70%" 		height="400px">
								<a href="<?php echo e(URL::asset('admin/upload_pdf/'.$p->Pdf)); ?>">test.pdf</a>
							</object>
						</div>

			 		</div> <?php $i++; } 
			 		else{ ?>
			 		<div id="menu<?php echo e($p->Class); ?>" class="tab-pane fade">
			    		
			    		<div align="center">
							<object data="<?php echo e(URL::asset('admin/upload_pdf/'.$p->Pdf)); ?>" type="application/pdf" width="70%" 		height="400px">
								<a href="<?php echo e(URL::asset('admin/upload_pdf/'.$p->Pdf)); ?>">test.pdf</a>
							</object>
						</div>

			 		</div>
			 	<?php $i++; } ?>
			 	
			 	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			  </div>
			</div>

			</body>
		</html>

	</div>
    <div id="div2" class="form" style="display: none">
    	<!DOCTYPE html>
		<html lang="en">
			<head>
			  <title>Bootstrap Example</title>
			  <meta charset="utf-8">
			  <meta name="viewport" content="width=device-width, initial-scale=1">
			  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
			  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
			</head>
			<body>

			<div class="container">
			  <h2>ROUTINE</h2>
			  <ul class="nav nav-tabs">
				<?php 
					$i = 0;
				?>
				<?php $__currentLoopData = $routine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php 	if($i==0){ ?>
						<li class="active"><a data-toggle="tab" href="#menu<?php echo e($q->Class); ?><?php echo($i) ?>">Class <?php echo e($q->Class); ?><br>Section <?php echo e($q->Section); ?></a></li>
					<?php $i++;
					 } 
			 		else{ ?> 	
			 			<li><a data-toggle="tab" href="#menu<?php echo e($q->Class); ?><?php echo($i) ?>">Class <?php echo e($q->Class); ?><br>Section <?php echo e($q->Section); ?></a></li>
			 		<?php $i++; } ?>	
		 		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  </ul>

			  <div class="tab-content">
				<?php 
					$i = 0;
				 ?>
				<?php $__currentLoopData = $routine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
				<?php 	if($i==0){ ?>
			  		<div id="menu<?php echo e($q->Class); ?><?php echo($i) ?>" class="tab-pane fade in active">
			    		
			    		<div align="center">
							<object data="<?php echo e(URL::asset('admin/upload_pdf/'.$q->Pdf)); ?>" type="application/pdf" width="70%" 		height="400px">
								<a href="<?php echo e(URL::asset('admin/upload_pdf/'.$q->Pdf)); ?>">test.pdf</a>
							</object>
						</div>

			 		</div> <?php $i++; } 
			 		else{ ?>
			 		<div id="menu<?php echo e($q->Class); ?><?php echo($i) ?>" class="tab-pane fade">
			    		
			    		<div align="center">
							<object data="<?php echo e(URL::asset('admin/upload_pdf/'.$q->Pdf)); ?>" type="application/pdf" width="70%" 		height="400px">
								<a href="<?php echo e(URL::asset('admin/upload_pdf/'.$q->Pdf)); ?>">test.pdf</a>
							</object>
						</div>

			 		</div>
			 	<?php $i++; } ?>
			 	
			 	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			  </div>
			</div>

			</body>
		</html>
    </div>

    <div id="div3" class="form" style="display: none">
    	<!DOCTYPE html>
		<html lang="en">
			<head>
			  <title>Bootstrap Example</title>
			  <meta charset="utf-8">
			  <meta name="viewport" content="width=device-width, initial-scale=1">
			  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
			  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
			</head>
			<body>

			<div class="container">
			  <h2>BOOKLIST</h2>
			  <ul class="nav nav-tabs">
				<?php 
					$i = 0;
				?>
				<?php $__currentLoopData = $booklist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php 	if($i==0){ ?>
						<li class="active"><a data-toggle="tab" href="#menu<?php echo e($r->Class); ?>">Class <?php echo e($r->Class); ?></a></li>
					<?php $i++;
					 } 
			 		else{ ?> 	
			 			<li><a data-toggle="tab" href="#menu<?php echo e($r->Class); ?>">Class <?php echo e($r->Class); ?></a></li>
			 		<?php $i++; } ?>	
		 		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  </ul>

			  <div class="tab-content">
				<?php 
					$i = 0;
				 ?>
				<?php $__currentLoopData = $booklist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
				<?php 	if($i==0){ ?>
			  		<div id="menu<?php echo e($r->Class); ?>" class="tab-pane fade in active">
			    		
			    		<div align="center">
							<object data="<?php echo e(URL::asset('admin/upload_pdf/'.$r->Pdf)); ?>" type="application/pdf" width="70%" 		height="400px">
								<a href="<?php echo e(URL::asset('admin/upload_pdf/'.$r->Pdf)); ?>">test.pdf</a>
							</object>
						</div>

			 		</div> <?php $i++; } 
			 		else{ ?>
			 		<div id="menu<?php echo e($r->Class); ?>" class="tab-pane fade">
			    		
			    		<div align="center">
							<object data="<?php echo e(URL::asset('admin/upload_pdf/'.$r->Pdf)); ?>" type="application/pdf" width="70%" 		height="400px">
								<a href="<?php echo e(URL::asset('admin/upload_pdf/'.$r->Pdf)); ?>">test.pdf</a>
							</object>
						</div>

			 		</div>
			 	<?php $i++; } ?>
			 	
			 	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			  </div>
			</div>

			</body>
		</html>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.home.teacher.teacher_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>