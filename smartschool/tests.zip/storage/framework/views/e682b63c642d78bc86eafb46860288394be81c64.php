<?php /* C:\Users\Arun kundu\Desktop\smartschool1\Smart_school\smartschool\resources\views/admin/students/students_admission.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
<h4 id="e">STUDENT ADMISSION</h4><br>
<div style="text-align: center;"><marquee style="width: 10%; background-color: black; color: white;" scrollamount="2" behavior = "alternate"><?php echo e(Session::get('msg')); ?></marquee></div>
<?php echo Form::open(['url' => '/student_admission_form', 'method'=>'POST', 'enctype'=>'multipart/form-data']); ?>

  
  <div style="margin: 0 15%; " class="form-row">
     <div class="form-group col-md-4">
      <label for="inputEmail4">Class</label>
      <input type="text" class="form-control" id="inputPassword4" name="Class" placeholder="Class...." required>
    </div>
    <div class="form-group col-md-4">
      <label for="inputPassword4">Session</label>
      <input type="text" class="form-control" id="inputPassword4" name="Session" placeholder="Session......" required>
    </div>
    <div class="form-group col-md-4">
      <label for="inputPassword4">Section</label>
      <input type="text" class="form-control" id="inputPassword4" name="Section" placeholder="Section......" required>
    </div>
    <div class="form-group col-md-4">
      <label for="inputEmail4">Student file (CSV file)</label>
      <input type="file" class="form-control" id="Image" name="Students_file" placeholder="Result (must be CSV file)" required>
    </div>
    <div align="center" class="form-group col-md-12">
     <button type="submit" class="btn btn-primary">UPLOAD</button>
    </div>
</div>
  <?php echo Form::close(); ?>

  <?php if($data['total_result']>0): ?>
 
  <div style="text-align: center;">
    
    Class : <?php echo e($data['Class']); ?> ||
       
    Session : <?php echo e($data['Session']); ?> ||
      
    Section : <?php echo e($data['Section']); ?> 
   

    <br>
    Total uploded : <?php echo e($data['total_result']); ?>

 
   <table style="text-align: center;" class="table">
    <thead>
      <tr>
        <th>Serial no</th>
        <th>Name</th>
        <th>Student ID</th>
        <th>Religion</th>
        <th>Father's name</th>
        <th>Gender</th>
      </tr>
    </thead>
    <tbody>
      
      <?php
        $i =0; 
      ?>
	
	<?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(++$i); ?></td>
          <td><?php echo e($p->Name); ?></td>
          <td><?php echo e($p->Student_id); ?></td>
          <td><?php echo e($p->Religion); ?></td>
          <td><?php echo e($p->Fathers_name); ?></td>
          <td><?php echo e($p->Gender); ?></td>
          
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	     
	<?php endif; ?>
    </tbody>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>