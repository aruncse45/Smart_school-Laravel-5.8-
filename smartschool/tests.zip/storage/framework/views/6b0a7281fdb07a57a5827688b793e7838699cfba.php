<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/admin/forms/image_gallery.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
<h4 id="e">IMAGE GALLERY</h4><br><br>
<div style="text-align: center;"><marquee style="width: 10%; background-color: black; color: white;" scrollamount="2" behavior = "alternate"><?php echo e(Session::get('msg')); ?></marquee>
  </div>
<?php echo Form::open(['url' => '/save_image_gallery', 'method'=>'POST', 'enctype'=>'multipart/form-data']); ?>

  
  <div class="form-row">
    <div class="form-group" style="width: 100%">
      <label for="inputEmail4">Images</label>
      <input type="file" class="form-control" id="Image" name="Image[]" multiple="multiple" placeholder="" required>
    </div>
  </div>
  
  <button type="submit" class="btn btn-lg btn-success btn-block">Submit</button>
  
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>