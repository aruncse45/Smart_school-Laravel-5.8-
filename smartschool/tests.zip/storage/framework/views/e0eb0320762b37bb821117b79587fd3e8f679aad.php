<?php /* C:\Users\Arun kundu\Desktop\smartschool\smartschool\resources\views/admin/forms/footer.blade.php */ ?>
<?php $__env->startSection('maincontent'); ?>
  
  <h4 id="e">FOOTER</h4><br><br>
  <div style="text-align: center;"><marquee style="width: 10%; background-color: black; color: white;" scrollamount="2" behavior = "alternate"><?php echo e(Session::get('msg')); ?></marquee>
  </div>
  <table class="table">
    <thead>
      <tr>
        <th>id</th>
        <th>Link Name</th>
        <th>Link URL</th>
        <th>Operation</th>
      </tr>
    </thead>
    <tbody>
      
      <?php
        $i =0; 
      ?>

      <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(++$i); ?></td>
          <td><?php echo e($p->Link_name); ?></td>
          <td><?php echo e($p->Link); ?></td>
          <td><a href="<?php echo e(url('/update_link_page/'.$p->id)); ?>">UPDATE</a></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>