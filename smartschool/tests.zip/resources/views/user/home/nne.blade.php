<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfobject/2.1.1/pdfobject.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfobject/2.1.1/pdfobject.min.js"></script>
</head>
<body>
	<con
	<div id="example1"></div>
	<script type="text/javascript">
		
		PDFObject.embed("{{$nne->Pdf}}", "#example1");
	</script>
</body>
</html>