<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class contact_info extends Model
{
    //
}
