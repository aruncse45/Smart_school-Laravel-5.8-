<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class teachers_staffs_info extends Model
{
    //
}
