<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class speech extends Model
{
    //
}
