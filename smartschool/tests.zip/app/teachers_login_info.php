<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class teachers_login_info extends Model
{
    //
}
