<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class committe extends Model
{
    //
}
