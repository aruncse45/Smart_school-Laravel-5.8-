<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class admission_id extends Model
{
    //
}
