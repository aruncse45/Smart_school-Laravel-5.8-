<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class booklist extends Model
{
    //
}
