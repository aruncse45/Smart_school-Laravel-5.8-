<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class students_information extends Model
{
    //
}
