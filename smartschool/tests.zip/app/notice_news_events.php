<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class notice_news_events extends Model
{
    //
}
