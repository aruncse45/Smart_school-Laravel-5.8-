# Smart_school
Back End Structure
Section:
1.	Dashboard
2.	Admissions
3.	Students
4.	Student Attendance
5.	Examination
6.	Accounting
7.	Academic
8.	Staff
9.	Communication
10.	Download
11.	Certificate/ID Card
12.	Reports
13.	Results
14.	Front End
15.	Setting
